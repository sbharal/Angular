"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("@angular/platform-browser");
require("@angular/platform-browser-dynamic");
require("@angular/core");
require("@angular/common");
require("@angular/http");
require("@angular/router");
// RxJS
require("rxjs");
//# sourceMappingURL=vendor.js.map